"""Anomaly detection models."""

